package hw01;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This class is a subclass of ArrayList<TeslaStock> and does not contain any
 * data fields. This class has a default constructor with no parameters.
 * This class shall have the following public, non-static, methods: 
 * printAllStocks, displayFirstTenStocks, displayLastTenStocks, 
 * computeAverageOpeningPrice, computeAverageClosingPrice, findMaxHighPrice, and
 * findMinLowPrice.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class StockList extends ArrayList<TeslaStock>
{

	/**This method prints each stock in the StockList to an output file called 
	 * all_stock_data.txt.
	 *  @return
	 */
	public void printAllStocks()
	{
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter (new FileWriter("src\\files\\all_stock_data.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for(int i =0; i< size(); i++) {
			try {
				writer.write(get(i).toString() + "\n");

				// System.out.println(get(i).toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**This method is used to display only the first 10 stocks in the StockList
	 * in the console.
	 *  @return
	 */
	public void displayFirstTenStocks()
	{
		int upperLimit = 10;
		if(size() <= upperLimit)
		{
			upperLimit = size();
		}

		for(int i = 0; i < upperLimit; i++) {
			System.out.println(get(i).toString());
		}
	}


	/**This method is used to display only the last 10 stocks in the StockList
	 * in the console.
	 * @return
	 */
	public void displayLastTenStocks()
	{
		int lowerLimit = size() - 10;
		if(lowerLimit < 0)
		{
			lowerLimit = 0;
		}

		for(int i = lowerLimit; i < size(); i++) {
			System.out.println(get(i).toString());
		}
	}

	/**This method should compute and return the average opening price of all 
	 * stock data in the StockList.
	 * @return
	 */

	public double computeAverageOpeningPrice() {

		double sum = 0;

		for(int i = 0; i < size(); i++) {
			sum += get(i).getOpeningPrice();	
		}

		double average = (sum/size());

		return average;
	}

	/**This method should compute and return the average closing price of all 
	 * stock data in the StockList.
	 * @return
	 */
	public double computeAverageClosingPrice() {

		double sum = 0;

		for(int i = 0; i < size(); i++) {
			sum += get(i).getClosingPrice();	
		}

		double average = (sum/size());

		return average;
	}

	/** Returns a TeslaStock object that is used to store the
	 *  maximum high price of all the stock data.
	 *  
	 * @return maxHighPrice
	 */
	public TeslaStock findMaxHighPrice()
	{
		TeslaStock maxHighPrice = get(0);

		for(int i = 0; i < size(); i++)
		{
			if(maxHighPrice.getHighPrice() < get(i).getHighPrice())
			{
				maxHighPrice = get(i);
			}
		}

		return maxHighPrice;
	}

	/** Returns a TeslaStock object that is used to store the
	 *  minimum low price of all the stock data.
	 *  
	 * @return minLowPrice
	 */
	public TeslaStock findMinLowPrice()
	{
		TeslaStock minLowPrice = get(0);

		for(int i = 0; i < size(); i++)
		{
			if(minLowPrice.getLowPrice() > get(i).getLowPrice())
			{
				minLowPrice = get(i);
			}
		}

		return minLowPrice;
	}
}