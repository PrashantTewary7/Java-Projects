package hw01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * This class contain the method necessary to read and parse the .csv file of 
 * stock information and does not contain any data fields. This class contains 
 * a private default constructor with no parameters. It has a method called 
 * readStockData to read the File object and process all of the stock data into 
 * TeslaStock objects and store each object in a StockList.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class StockReader {
	
	/**Private default constructor with no parameters  to prevent the class from
	 * being instantiated since the class will only contain static methods.
	 */
	private StockReader(){
		
	}

	/**This method returns a StockList object once all data has been processed
	 * by taking a File object as a parameter. This File object should link to 
	 * the stock market data in your files folder created previously. It also 
	 * validates that the given File object is a .csv file.  If it is not, then 
	 * this method shall throw an IllegalArgumentException. The method will 
	 * read the File object and process all of the stock data into TeslaStock 
	 * objects and store each object in a StockList.
	 * 
	 * <p>
	 * 
	 * @param file
	 * @return list
	 */
	public static StockList readStockData(File file) {

		if(!file.getName().substring(file.getName().length()-4).equals(".csv"))
		{
			throw(new IllegalArgumentException());
		}

		BufferedReader read = null;

		try {
			read = new BufferedReader(new FileReader (file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		StockList list = new StockList();

		try {
			read.readLine();

			String line = read.readLine();

			while(line != null) {


				String[] values = line.split(",");

				TeslaStock dummy = new TeslaStock(null, 0, 0, 0, 0);

				dummy.setDate(values[0]);
				dummy.setOpeningPrice(Double.parseDouble(values[1]));
				dummy.setHighPrice(Double.parseDouble(values[2]));
				dummy.setLowPrice(Double.parseDouble(values[3]));
				dummy.setClosingPrice(Double.parseDouble(values[4]));

				list.add(dummy);

				line = read.readLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
}