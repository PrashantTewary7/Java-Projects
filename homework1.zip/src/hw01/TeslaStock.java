package hw01;
/**
 * This class will be used to represent Tesla's stock data in the project. 
 * It contains data fields for the date, opening price, low price, high price, 
 * and closing price of the stock. Getters and setters are created for each 
 * data field. This class does not contain any methods to read/write the data 
 * and only implements them. It has a constructor named TeslaStock exactly 
 * like the name of the class to initializes the newly created object before 
 * using them.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class TeslaStock {

	/**This {@code String} stores the date of the Tesla stock.*/
	private String date;

	/**This value is the opening price of the Tesla stock in this class*/
	private double openingPrice; 
	/**This value is the high price of the Tesla stock in this class*/
	private double highPrice;
	/**This value is the low price of the Tesla stock in this class*/
	private double lowPrice;
	/**This value is the closing price of the Tesla stock in this class*/
	private double closingPrice;


	/**
	 * Initializes a {@code TeslaStock} object using the given parameter
	 * values.
	 * 
	 * @param date	Date of the Tesla stock in this instance.
	 * @param openingPrice	Opening price of the Tesla stock in this instance.
	 * @param highPrice	High price of the Tesla stock in this instance.
	 * @param lowPrice	Low price of the Tesla stock in this instance.
	 * @param closingPrice	Closing price of the Tesla stock in this instance.
	 */
	public TeslaStock(String date, double openingPrice, double highPrice, double lowPrice, double closingPrice) 
	{
		this.date = date;
		this.openingPrice = openingPrice;
		this.highPrice = highPrice;
		this.lowPrice = lowPrice;
		this.closingPrice = closingPrice;
	}

	/**
	 * Returns the date
	 * 
	 * @return date
	 */
	public String getDate()
	{
		return date;
	}

	/**
	 * Sets the date.
	 * 
	 * @param date the date to be set
	 */
	public void setDate(String date)
	{
		this.date=date;
	}

	/**
	 * Returns the opening price
	 * 
	 * @return openingPrice
	 */
	public double getOpeningPrice()
	{
		return openingPrice;
	}

	/**
	 * Sets the opening price.
	 * 
	 * @param openingPrice the opening price to be set
	 */
	public void setOpeningPrice(double openingPrice)
	{
		this.openingPrice=openingPrice;
	}

	/**
	 * Returns the high price
	 * 
	 * @return highPrice
	 */
	public double getHighPrice()
	{
		return highPrice;
	}

	/**
	 * Sets the high price.
	 * 
	 * @param highPrice the high price to be set
	 */
	public void setHighPrice(double highPrice)
	{
		this.highPrice=highPrice;
	}

	/**
	 * Returns the low price
	 * 
	 * @return lowPrice
	 */
	public double getLowPrice()
	{
		return lowPrice;
	}

	/**
	 * Sets the low price.
	 * 
	 * @param lowPrice the low price to be set
	 */
	public void setLowPrice(double lowPrice)
	{
		this.lowPrice=lowPrice;
	}

	/**
	 * Returns the closing price
	 * 
	 * @return closingPrice
	 */
	public double getClosingPrice()
	{
		return closingPrice;
	}

	/**
	 * Sets the closing price.
	 * 
	 * @param closingPrice the closing price to be set
	 */
	public void setClosingPrice(double closingPrice)
	{
		this.closingPrice=closingPrice;
	}

	/**
	 * This method creates a String representation of TeslaStock class by 
	 * displaying the following data fields.
	 *
	 * @return The String representing this object.
	 */
	public String toString() {
		String out = "Date:\t" + date + "\nOpening Price:\t" + openingPrice + "\nHigh Price:\t" 
				+ highPrice + "\nLow Price:\t" + lowPrice + "\nClosing Price:\t" + closingPrice;

		return out;
	}
}