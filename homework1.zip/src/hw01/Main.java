package hw01;

import java.io.File;

/**
 * This is the Main class of the project that contains the main() method. This 
 * creates a File object linked to your .csv file and reads all the stock data 
 * from the file and obtain a StockList object. It executes each method from  
 * the StockList class and shows the results of each in the console as well as 
 * in the output file.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class Main {

	public static void main(String[] args)
	{
		File file = new File("src\\\\files\\\\tesla_historic_stock_prices.csv");

		StockList list = StockReader.readStockData(file);

		list.printAllStocks();
		list.displayFirstTenStocks();

		System.out.println("==================");
		list.displayLastTenStocks();

		list.computeAverageOpeningPrice();

		list.computeAverageClosingPrice();

		list.findMaxHighPrice();

		list.findMinLowPrice();
	}
}