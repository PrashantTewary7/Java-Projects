package hw03;

import java.util.Random;

/**
 * This class uses generics to design a custom Array class along with adding 
 * additional features not available to normal arrays. It uses Comparable method
 *  that is built in in the IDE to compare data while implementing methods that 
 * involves swapping, reversing, replacing, or sorting the entries in the array.
 *  The class has get() and put() methods which are overloaded to serve 
 * different purposes. Moreover, the equals() and toString() methods are 
 * overridden to give the MyArray class its own implementation.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class MyArray<E extends Comparable<E>> {
	/**This 1D array stores the elements of the data in this class*/
	public E[] data;

	/**
	 * This method determines the size of the array in this class.
	 * 
	 * @param size	The size of the array in this instance.
	 */
	@SuppressWarnings("unchecked")
	public MyArray(int size)
	{
		this.data = (E[])(new Comparable[size]);
	}

	/**This constructor can accept an array or a comma-separated list of 
	 * values to make a deep copy of the array to prevent shared references.*/
	@SuppressWarnings("unchecked")
	public MyArray(E ... elements)
	{
		this.data = (E[])(new Comparable[elements.length]);
		System.arraycopy(elements, 0, this.data, 0, elements.length);
	}

	/**
	 * This method returns the data at the given index in the array by taking 
	 * an integer index as a parameter in the class.
	 * 
	 * @param index		The given entry in the array
	 * @return index 	Returns the specified entry in the array
	 */
	public E get(int index)
	{
		return data[index];
	}

	/**
	 * This method returns a new MyArray object with values between indices 
	 * start and end inclusive by taking two integer parameters. 
	 * 
	 * @param start		The beginning of the entry in the array
	 * @param end		The end of the entry in the array
	 * 
	 * @return new MyArray<E>(elements)		A new MyArray object
	 */
	public MyArray<E> get(int start, int end)
	{
		@SuppressWarnings("unchecked")
		E[] elements = (E[])(new Comparable[(end-start)+1]);

		for(int i=start, j = 0; i<=end; i++, j++)
		{
			elements[j] = data[i];
		}

		return new MyArray<E>(elements);
	}
	
	/**
	 * This method takes two integer parameters, index and a value, and place 
	 * the value at the given index. 
	 * 
	 * @param index		The specified element in the array to be placed with a 
	 * 					new value
	 * @param value		The new value that replaces the old value in the 
	 * 					specified element in the array
	 */
	public void put(int index, E value)
	{
		data[index] = value;
	}

	/**
	 * This method takes 3 parameters, the start index, end index, and a 
	 * variable length parameter list of values of any length. It takes the 
	 * values and places them into the array replacing the values between the 
	 * start index position and the end index position (inclusive) by making a 
	 * deep copy of the array.
	 * 
	 * @param start		The start index position of the new entry(s) in the 
	 * 					array
	 * @param end		The end index position of the new entry(s) in the array
	 */
	public void put(int start, int end, @SuppressWarnings("unchecked") E ... elements)
	{
		System.arraycopy(elements, 0, this.data, start, (end-start)+1);
	}

	/**
	 * This method takes a single MyArray object as input and return whether or 
	 * not this MyArray object is equal to the parameter MyArray object.
	 * 
	 * @param object	Takes an array as the object
	 * 
	 * @return true		If the condition is valid, it returns true
	 * @return false	If the condition is in valid, it returns false
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object object)
	{
		if(object instanceof MyArray<?>)
		{
			MyArray<?> other = ((MyArray<?>)object);

			if(data.length == other.data.length)
			{
				for(int i=0; i<data.length; i++)
				{
					if(data[i].getClass().equals(other.data[i].getClass()))
					{		
						if((data[i].compareTo((E)other.data[i])) != 0)
							return false;
					}
					else
						return false;
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * This method takes no parameters and finds and returns the maximum value 
	 * in the array.
	 * 
	 * @return maxValue		The maximum value in the array.
	 */
	public E max()
	{
		E maxValue = data[0];
		for(int i=1; i<data.length; i++)
		{
			if((data[i].compareTo(maxValue)) > 0)
				maxValue = data[i];
		}
		return maxValue;
	}

	/**
	 * This method takes no parameters and finds and returns the minimum value 
	 * in the array.
	 * 
	 * @return minValue		The minimum value in the array.
	 */
	public E min()
	{
		E minValue = data[0];
		for(int i=1; i<data.length; i++)
		{
			if((data[i].compareTo(minValue)) < 0)
				minValue = data[i];
		}
		return minValue;
	}

	/**
	 * This method takes no parameters and reverses the existing array without 
	 * returning a new array.
	 */
	public void reverse()
	{
		for(int i=0; i<(data.length/2); i++)
		{
			E tempElement = data[i];
			data[i] = data[(data.length-1)-i];
			data[(data.length-1)-i] = tempElement;
		}
	}

	/**
	 * This method takes no parameters and shuffles the existing array without 
	 * returning a new array.
	 */
	public void shuffle()
	{
		Random random = new Random();
		int index1, index2;
		for(int i=0; i<(data.length/2); i++)
		{
			index1 = random.nextInt(data.length);
			
			index2 = random.nextInt(data.length);
			
			E tempElement = data[index1];
			
			data[index1] = data[index2];
			
			data[index2] = tempElement;
		}
	}

	/**
	 * This method takes an integer value as a parameter and left shifts the 
	 * elements in the array by the given number of positions. It wraps the 
	 * beginning around to the end without returning a new MyArray.
	 * 
	 * @param shiftDistance		The number of positions to left shift the 
	 * 							elements in the array.
	 */
	public void leftShift(int shiftDistance)
	{
		for(int i=0; i<shiftDistance; i++)
		{
			E firstElement = data[0];

			for(int j=0; j<(data.length-1); j++)
			{
				data[j] = data[j+1];
			}

			data[(data.length-1)] = firstElement;
		}
	}

	/**
	 * This method takes an integer value as a parameter and right shifts the 
	 * elements in the array by the given number of positions. It wraps the 
	 * end around to the beginning without returning a new MyArray.
	 * 
	 * @param shiftDistance		The number of positions to right shift the 
	 * 							elements in the array.
	 */
	public void rightShift(int shiftDistance)
	{
		for(int i=0; i<shiftDistance; i++)
		{
			E lastElement = data[(data.length-1)];

			for(int j=(data.length-1); j>0; j--)
			{
				data[j] = data[j-1];
			}

			data[0] = lastElement;
		}
	}

	/**
	 * This method returns the current size of the array.
	 * 
	 * @return data.length		The size of the array.
	 */
	public int size()
	{
		return data.length;
	}

	/**
	 * This method prints a String representation of the array. It displays 
	 * each value of the array on one line and should separate each value with 
	 * a comma and one space.
	 * 
	 * @return string	All the values in the array.
	 */
	@Override
	public String toString()
	{
		String string = "";
		for(int i=0; i<(data.length-1); i++)
			string += data[i]+", ";
		
		string += data[(data.length-1)];

		return string;
	}

	/**
	 * This method sorts the existing array in alphabetical order by using 
	 * bubble sort without creating a new array.
	 */
	public void sort()
	{
		boolean swappedItem = true;

		while(swappedItem)
		{
			swappedItem = false;
			for(int i=0; i<(data.length-1); i++)
			{
				if((data[i].compareTo(data[i+1])) > 0)
				{
					swappedItem = true;
					E tempElement = data[i];
					data[i] = data[i+1];
					data[i+1] = tempElement;
				}
			}
		}
	}
}