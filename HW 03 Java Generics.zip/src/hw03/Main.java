package hw03;

/**
 * This class tests the MyArray class to ensure that all functionality of the 
 * MyArray class works. It uses 1D String array channels of 12 elements, which 
 * consists of a list of TV channels and the array is implemented by calling 
 * all the methods created in the MyArray class to test the functionality. In  
 * addition, there is a 1D integer array numbers created of the same size as  
 * the channels to test if the equals() method holds true or false.
 * 
 * <p>
 * 
 * * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class Main {

	public static void main(String[] args) {

		String channels[] = {"NBC", "ESPN", "Discovery", "HBO", "ABC", "TNT", "CNN", "Comedy Central", 
				"MTV", "FOX", "Nickelodeon", "CBS"};

		MyArray<String> stringArray = new MyArray<String>(channels);

		System.out.println("Displaying the current stringArray: " + stringArray);

		System.out.println("Display elements from index 4 to 9 in the current stringArray: " + stringArray.get(4, 9));

		stringArray.put(4, "National Geographic");
		
		System.out.println("Displaying the current stringArray after using put(index, value) method: " + stringArray);
		
		System.out.println("7th element of the current stringArray: " + stringArray.get(7));
		
		System.out.println("Minimum element in the stringArray: " + stringArray.min());

		System.out.println("Maximum element in the stringArray: " + stringArray.max());
		
		System.out.println("Is stringArray == stringArray?: " + stringArray.equals(stringArray));

		MyArray<String> stringArray2 = new MyArray<>(channels);

		System.out.println("Is stringArray == stringArray2?: " + stringArray.equals(stringArray2));

		/* Creating an Integer array to test if the equals() method for the 
		String array returns false*/
		Integer numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9 , 10, 11, 12};

		MyArray<Integer> intArray = new MyArray<>(numbers);

		System.out.println("Is stringArray == intArray?: "+stringArray.equals(numbers));

		System.out.println("Displaying the current stringArray before changes: " + stringArray);

		stringArray.put(3, 6, new String[] {"TBS", "Cartoon Network", "TLC", "The Food Network"});

		System.out.println("\nDisplaying the current stringArray after using "
				+ "put(start, end, any number of comma separated values) method: \n" + stringArray);
		
		System.out.println("Minimum element in the current stringArray: " + stringArray.min());

		System.out.println("Maximum element in the current stringArray: " + stringArray.max());
		
		stringArray.reverse();

		System.out.println("Reversing the order of the elements from last to first in the array: " + stringArray);
		
		System.out.println("Displaying the current stringArray after changes: " + stringArray);
		
		stringArray.leftShift(2);

		System.out.println("Shifting first 2 elements to the end of the array: " + stringArray);
		
		stringArray.shuffle();

		System.out.println("Shuffling the elements in the array: " + stringArray);
		
		System.out.println("\nDisplaying the current stringArray after changes: " + stringArray);

		stringArray.rightShift(2);

		System.out.println("Shifting last 2 elements to the start of the array: " + stringArray);

		System.out.println("Size of the current array: " + stringArray.size() + " elements");

		stringArray.sort();
		
		System.out.println("Sorting values of the array in alphabetical order: " + stringArray);
		
		System.out.println("\nDisplaying the final stringArray: " + stringArray);
	}
}