package hw04;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class uses recursion with backtracking to find all possible solutions 
 * by trying all rotations of each tile in all 7 board positions until the 
 * program is exhausted with all the possibilities for no solution or all valid 
 * solution has been found. If a solution is found, then the configuration of 
 * the hexagons is displayed on the console. If no solution is found then a 
 * message is display stating that there is no solution for the given hexagon 
 * tiles. Moreover, this class implements all the methods created in the Hexagon 
 * class to get the result. It uses an object named Hexagon which reads the 
 * colors from the input file separated by commas, with no spaces in between, 
 * which makes it easier to parse the color data. In addition, the class uses 
 * BufferedReader to read a text file containing information that'll be the 
 * input for the 7 tiles in the program. 
 * 
 * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class Main {

	public static void main(String[] args) {

		try {
			BufferedReader colorReceiver = new BufferedReader(new FileReader("src/hw04/tileset1-1.txt"));	//relative path
			List<Hexagon> list = new ArrayList();

			for (int i = 0; i < 7; i++) {

				String store1=colorReceiver.readLine();

				String store2=store1.substring(8);

				String [] array = store2.split(",");

				Hexagon hexagon = new Hexagon(array[0], array[1], array[2], array[3], array[4], array[5], i);

				list.add(hexagon);
			}

			System.out.println("                       SD   SE   SF   SA   SB   SC         ");

			int count = 1; 

			for(Hexagon hexagon:list) {

				System.out.println("Position "+ count++ +": Tile #"+ (hexagon.getTileNumber()) +":   "
						+ hexagon.getSA()+"    " + hexagon.getSB()+"    "+ hexagon.getSC()+"    "
						+ hexagon.getSD()+"    "+ hexagon.getSE()+"    " + hexagon.getSF()+"   "); //index of hexagon h in list tile
			}

			List<Hexagon> board = new ArrayList();

			/**This is an instance of calling the recursive function.*/
			recursiveRotation(board, list, 0, 1);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This is static method that uses recursion with backtracking to find 
	 * all possible solutions by increasing the count of position by 1 and 
	 * trying all rotations of each tile in all 7 board positions until the 
	 * program is exhausted with all the possibilities for no solution or all 
	 * valid solution has been found. If a solution is found, then the 
	 * configuration of the hexagons is displayed on the console as well as 
	 * returns the count of the number of times a solution is produced.
	 * 
	 * @param board		Represents the board containing all 7 tiles in this 
	 * 					instance, which is a list of hexagon.
	 * @param tile		Represents each tile containing all 6 sides in this 
	 * 					instance, which is a list of hexagon.
	 * @param position	Represents the position of each tile on the board in 
	 * 					this instance.
	 * 
	 * @return noOfSoln 	Returns the count of the number of times a solution 
	 * 						is produced.
	 */
	public static int recursiveRotation(List <Hexagon> board, List <Hexagon> tile, int position, int noOfSoln) {
		
		for (int i = 0; i < tile.size(); i++) {
			
			board.add(tile.get(i));
			tile.remove(i);

			for (int j = 0; j < 6; j++) {
				if (Hexagon.matching(board)) {

					if(position == 6) {
						System.out.println("Solution # "+ noOfSoln++ +"----------------------------------------\n");
						System.out.println("                       SD   SE   SF   SA   SB   SC         ");

						int count = 1;
						for(Hexagon hexagon:board) {
							System.out.println("Position "+ count++ +": Tile #"+ (hexagon.getTileNumber()+1) +":   "
									+ hexagon.getSA()+"    "+ hexagon.getSB()+"    "+ hexagon.getSC()+"    "
									+ hexagon.getSD()+"    "+ hexagon.getSE()+"    "+ hexagon.getSF()+"   "); //index of obeject hexagon in list tile
						}
						System.out.println("\n---------------------------------------------------");
					}
					else 	
						noOfSoln = recursiveRotation(board, tile, position+1, noOfSoln);	//backtracking
				} 
				board.get((board.size()-1)).rotate();
			}			 

			tile.add(board.get(board.size()-1));
			board.remove(board.size()-1);
		}
		return noOfSoln;
	}
}