package hw04;

import java.util.List;

/**
 * This class contains methods to create 7 hexagon tiles on a board with each 
 * tile having 6 colored segments chosen randomly from the following: Red, Blue, 
 * Yellow, Green, Orange, and Purple. Moreover, it places the 7 hexagon tiles 
 * on a board such that a tile is placed in the center of the board and the 6 
 * remaining tiles are placed going clockwise around the first starting at the 
 * 12 o clock position by using rotate method without changing the labels. It 
 * ensures that the adjacent segments of the hexagons have the same color in 
 * order for the placement to be valid by using matching method.
 *
 * <p>
 * 
 * It contains data fields such as position: to store the position on the board 
 * where a tile can be placed, and tileNumber: to store the assigned number of 
 * the tile. 
 * 
 * <p>
 * 
 * It has a constructor named Hexagon that takes 6 String values to store the 
 * single colors representing the side colors and 1 integer value to store the 
 * number of the tile as it was assigned by the data from the input file.
 * 
 * <p>
 * 
 * @author Prashant Tewary, 401919840, CS2013 - 09/10
 */
public class Hexagon {

	/**This value is the position on the board where a tile can be placed*/
	private int position;

	/**This {@code String} stores the colors representing Side A, Side B, 
	 * Side C, Side D, Side E, Side F, respectively, of each tile.*/
	private String SA, SB, SC, SD, SE, SF;

	/**This value is the assigned number of the tile.*/
	private int tileNumber;

	/**
	 * Returns the color representing Side A
	 * 
	 * @return SA
	 */
	public String getSA() {
		return SA;
	}

	/**
	 * Returns the color representing Side B
	 * 
	 * @return SB
	 */
	public String getSB() {
		return SB;
	}

	/**
	 * Returns the color representing Side C
	 * 
	 * @return SC
	 */
	public String getSC() {
		return SC;
	}

	/**
	 * Returns the color representing Side D
	 * 
	 * @return SD
	 */
	public String getSD() {
		return SD;
	}

	/**
	 * Returns the color representing Side E
	 * 
	 * @return SE
	 */
	public String getSE() {
		return SE;
	}

	/**
	 * Returns the color representing Side F
	 * 
	 * @return SF
	 */
	public String getSF() {
		return SF;
	}

	/**
	 * Returns the assigned number to the tile
	 * 
	 * @return tileNumber
	 */
	public int getTileNumber() {
		return tileNumber;
	}

	/**
	 * Initializes a {@code Hexagon} object using the given parameter
	 * values.
	 * 
	 * @param SA	The color representing Side A in this instance.
	 * @param SB	The color representing Side B in this instance.
	 * @param SC	The color representing Side C in this instance.
	 * @param SD	The color representing Side D in this instance.
	 * @param SE	The color representing Side E in this instance.
	 * @param SF	The color representing Side F in this instance.
	 * @param tileNumber	The assigned number for the tile in this instance.
	 */
	public Hexagon(String SA, String SB, String SC, String SD, String SE, String SF, int tileNumber) {
		this.SA=SA;
		this.SB=SB;
		this.SC=SC;
		this.SD=SD;
		this.SE=SE;
		this.SF=SF;
		this.tileNumber= tileNumber;
	}

	/**This method rotates the colors of the sides that can rotate without 
	 * changing the labels SA, SB, SC, SD, SE, and SF.
	 */
	public void rotate() {
		String temp;

		temp = SF;
		SF=SE;
		SE=SD;
		SD=SC;
		SC=SB;
		SB=SA;
		SA=temp;	
	}

	/**This method ensures that the adjacent segments of the hexagons have the 
	 * same color in order for the placement to be valid.
	 */
	public static boolean matching(List <Hexagon> board) {
		if(board.size()==1)
			return true;
		if(!(board.get(0).SA.equals(board.get(1).SD)))
			return false;

		if(board.size()==2)
			return true;
		if(!(board.get(0).SB.equals(board.get(2).SE)))
			return false;
		if(!(board.get(1).SC.equals(board.get(2).SF)))
			return false;

		if(board.size()==3)
			return true;
		if(!(board.get(0).SC.equals(board.get(3).SF)))
			return false;
		if(!(board.get(2).SD.equals(board.get(3).SA)))
			return false;

		if(board.size()==4)
			return true;
		if(!(board.get(0).SD.equals(board.get(4).SA)))
			return false;
		if(!(board.get(3).SE.equals(board.get(4).SB)))
			return false;

		if(board.size()==5)
			return true;
		if(!(board.get(0).SE.equals(board.get(5).SB)))
			return false;
		if(!(board.get(4).SF.equals(board.get(5).SC)))
			return false;

		if(board.size()==6)
			return true;
		if(!(board.get(0).SF.equals(board.get(6).SC)))
			return false;
		if(!(board.get(5).SA.equals(board.get(6).SD)))
			return false;
		if(!(board.get(1).SE.equals(board.get(6).SB)))
			return false;

		return true;
	}
}