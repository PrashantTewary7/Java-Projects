package hw05;

public class Array2DTester {

	public static void main(String[] args) {
		testGet();
		testAddFirstCol();
		testAddFirstRow();
	}

	public static void testGet() {
		System.out.println("Testing get()------------------");

		Integer[][] expectedValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Integer[][] actualValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Array2D<Integer> list = new Array2D<>(actualValues);

		for (int i = 0 ; i < expectedValues.length ; i++) {
			for (int j = 0 ; j < expectedValues[0].length ; j++) {
				int expected = expectedValues[i][j];
				System.out.println(i + "  "+ j);

				int actual = list.get(i,j);

				boolean isCorrect = (expected == actual);

				System.out.printf("%-15s %d\n" ,"Expected:", expected);
				System.out.printf("%-15s %d\n" ,"Actual:", actual);
				System.out.printf("%-15s %b\n" ,"isCorrect?:", isCorrect);
				System.out.println();
			}}
		System.out.println("End Testing get()--------------------");
	}

	public static void testAddFirstCol() {
		System.out.println("Testing Add First Col------------------");

		Integer[][] expectedValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Integer[][] actualValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Array2D<Integer> list = new Array2D<>();

		list.addFirstCol(actualValues[0]);
		list.addFirstCol(actualValues[1]);


		String expected = "10, 20, 30, 40, 50"
				+ "\n\t\t100,200,300,400,500";
		String actual = list.toString();
		boolean isCorrect = expected.equals(actual);

		System.out.printf("%-15s %s\n" ,"Expected:", expected);
		System.out.printf("%-15s %s\n" ,"Actual:", actual);
		System.out.printf("%-15s %b\n" ,"Is correct?:", isCorrect);

		System.out.println("End Testing Add First--------------------");
	}

	public static void testAddFirstRow() {
		System.out.println("Testing Add First Row------------------");

		Integer[][] expectedValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Integer[][] actualValues = {{10, 20, 30, 40, 50},{100,200,300,400,500}};

		Array2D<Integer> list = new Array2D<>();

		list.addFirstRow(actualValues[0][0]);
		list.addFirstRow(actualValues[0][1]);
		list.addFirstRow(actualValues[0][2]);
		list.addFirstRow(actualValues[0][3]);

		String expected = "10, 20, 30, 40, 50"
				+ "\n\t\t100,200,300,400,500";
		String actual = list.toString();
		boolean isCorrect = expected.equals(actual);

		System.out.printf("%-15s %s\n" ,"Expected:", expected);
		System.out.printf("%-15s %s\n" ,"Actual:", actual);
		System.out.printf("%-15s %b\n" ,"Is correct?:", isCorrect);

		System.out.println("End Testing Add First--------------------");
	}
}

//
//
//list.addFirstRow(actualValues[0][0],
//		list.addFirstCol(actualValues[0][1].....4
//				
//addLastCol
//{
//			list.addLastCol(actualValues[0][0]);	
//}
//				