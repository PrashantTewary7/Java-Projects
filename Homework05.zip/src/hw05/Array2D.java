package hw05;

import java.util.ArrayList;

public class Array2D<E> {
	private int rowSize;
	private int colSize;

	protected Array2DNode<E> head;

	private Array2DNode<E> rowTail;
	private Array2DNode<E> colTail;

	Array2D(){
		this.head = this.rowTail = this.colTail = null;
		this.rowSize = this.colSize = 0;
	}

	Array2D(E[][] values){
		for (E []value : values) {
			this.addFirstRow(value);
		}
	}

	public E get(int rowIndex, int colIndex) throws IndexOutOfBoundsException {
		if (rowIndex < 0 || rowIndex >= this.rowSize || colIndex < 0 || colIndex  >= this.colSize) {
			throw new IndexOutOfBoundsException("ERROR");
		}

		Array2DNode<E> current = this.head;
		int currentIndex = 0;

		while(currentIndex != rowIndex) {
			current = current.nextRow;
			currentIndex++;
		}

		currentIndex = 0;

		while(currentIndex != colIndex) {
			current = current.nextCol;
			currentIndex++;
		}

		return current.item;
	}

	public void set(int rowIndex, int colIndex, E item) throws IndexOutOfBoundsException {
		if (rowIndex < 0 || rowIndex >= this.rowSize || colIndex < 0 || colIndex  >= this.colSize) {
			throw new IndexOutOfBoundsException("ERROR");
		}

		Array2DNode<E> current = this.head;
		int currentIndex = 0;

		while(currentIndex != rowIndex) {
			current = current.nextRow;
			currentIndex++;
		}

		while(currentIndex != colIndex) {
			current = current.nextCol;
			currentIndex++;
		}
		current.item=item;
	}


	public ArrayList<E> getCol(int colIndex) {
		if (colIndex < 0 || colIndex >= this.colSize) {
			throw new IndexOutOfBoundsException("ERROR");
		}

		Array2DNode<E> current = this.head;
		int currentIndex = 0;

		while(currentIndex != colIndex) {
			current = current.nextCol;
			currentIndex++;
		}

		ArrayList<E> array = new ArrayList<E>();

		for(int i=0; i<rowSize;i++) {
			current=current.nextRow;
			array.add(current.item);
		}
		return array;
	}

	public ArrayList<E> getRow(int rowIndex) {
		if (rowIndex < 0 || rowIndex >= this.rowSize) 
			throw new IndexOutOfBoundsException("ERROR");

		Array2DNode<E> current = this.head;
		int currentIndex = 0;

		while(currentIndex != rowIndex) {
			current = current.nextRow;
			currentIndex++;
		}

		ArrayList<E> array = new ArrayList<E>();

		for(int i=0; i<colSize;i++) {
			current=current.nextCol;
			array.add(current.item);
		}
		return array;
	}

	public int colSize() {return colSize;}

	public int rowSize() {return rowSize;}

	@Override
	public String toString() {
		String data="";
		Array2DNode<E> first=head,last=head;

		for(int i=0;i<rowSize;i++) {
			for(int j=0;j<colSize;j++) {
				last=last.nextCol;
				data+=last.item.toString();
				data+=" , ";
			}
			data+="\n";
			first=first.nextRow;
			last=first;
		}			
		return data;
	}

	public String toStringColByCol(){
		String data="";
		Array2DNode<E> first=head,last=head;

		for(int i=0;i<colSize;i++) {
			for(int j=0;j<rowSize;j++) {
				last=last.nextRow;
				data+=last.item.toString();
				data+=" , ";
			}
			data+="\n";
			first=first.nextCol;
			last=first;
		}			
		return data;
	}

	public void deleteFirstRow() {
		if (this.isEmpty())
			throw new IllegalStateException("List is empty.");

		if (this.rowSize == 1) 
			this.head = this.rowTail = null;
		else 
			this.head = this.head.nextRow;

		this.rowSize--;
	}

	public void deleteFirstCol() {
		if (this.isEmpty()) 
			throw new IllegalStateException("List is empty.");

		if (this.colSize == 1) 
			this.head = this.colTail = null;
		else 
			this.head = this.head.nextCol;

		this.colSize--;
	}

	public void deleteLastRow() {
		if(this.isEmpty()) 
			throw new IllegalStateException("List is empty");

		if (this.rowSize == 1) 
			this.head = this.rowTail = null;
		else {
			Array2DNode<E> current = this.head;
			Array2DNode<E> previous = this.head;

			while(current.nextRow != null) {
				previous = current;
				current = current.nextRow;
			}
			this.rowTail = previous;
			this.rowTail.nextRow = null;
		}
		this.rowSize--;
	}

	public void deleteLastCol() {
		if(this.isEmpty()) 
			throw new IllegalStateException("List is empty");

		if (this.colSize == 1) 
			this.head = this.colTail = null;
		else {
			Array2DNode<E> current = this.head;
			Array2DNode<E> previous = this.head;

			while(current.nextCol != null) {
				previous = current;
				current = current.nextCol;
			}
			this.colTail = previous;
			this.colTail.nextCol = null;
		}
		this.colSize--;
	}

	public void deleteRow(int rowIndex) {
		if(this.isEmpty()) 
			throw new IllegalStateException("List is empty");

		if(rowIndex < 0 || rowIndex >= this.rowSize) 
			throw new IndexOutOfBoundsException("Index out of bounds");

		if(rowIndex == 0) 
			this.deleteFirstRow();
		else if (rowIndex == (this.rowSize - 1)) 
			this.deleteLastRow();
		else {
			Array2DNode<E> current = this.head;
			int currentIndex = 0;

			while(currentIndex < (rowIndex - 1)) {
				current = current.nextRow;
				currentIndex++;
			}

			while(current.nextCol != null) {
				current.nextRow = current.nextRow.nextRow;
				current = current.nextCol;
			}
			this.rowSize--;
		}	
	}

	public void deleteCol(int colIndex) {
		if(this.isEmpty()) 
			throw new IllegalStateException("List is empty");

		if(colIndex < 0 || colIndex >= this.colSize) 
			throw new IndexOutOfBoundsException("Index out of bounds");
		if(colIndex == 0) 
			this.deleteFirstCol();
		else if (colIndex == (this.colSize - 1)) 
			this.deleteLastCol();
		else {
			Array2DNode<E> current = this.head;
			int currentIndex = 0;

			while(currentIndex < (colIndex - 1)) {
				current = current.nextCol;
				currentIndex++;
			}

			while(current.nextRow != null) {
				current.nextCol = current.nextCol.nextCol;
				current = current.nextRow;
			}
			this.colSize--;
		}	
	}

	public void insertRow(int rowIndex, E ... values) {
		if (rowIndex < 0 || rowIndex > this.rowSize) 
			throw new IndexOutOfBoundsException("ERROR");

		if (rowIndex == 0) 
			this.addFirstRow(values);
		else if (rowIndex == this.rowSize) 
			this.addLastRow(values);
		else {
			Array2DNode<E> temp = new Array2DNode(values);
			Array2DNode<E> current = this.head;
			int currentIndex = 0;

			while(currentIndex != (rowIndex - 1)) {
				current = current.nextRow;
				currentIndex++;
			}
			temp.nextRow = current.nextRow;
			current.nextRow = temp;
			this.rowSize++;
		}
	}

	public void insertCol(int colIndex, E ... values) {
		if (colIndex < 0 || colIndex > this.colSize) 
			throw new IndexOutOfBoundsException("ERROR");

		if (colIndex == 0) 
			this.addFirstCol(values);
		else if (colIndex == this.colSize) 
			this.addLastCol(values);
		else {
			Array2DNode<E> temp = new Array2DNode(values);
			Array2DNode<E> current = this.head;
			int currentIndex = 0;

			while(currentIndex != (colIndex - 1)) {
				current = current.nextCol;
				currentIndex++;
			}
			temp.nextCol = current.nextCol;
			current.nextCol = temp;
			this.colSize++;
		}
	}

	public boolean isEmpty() {
		return this.head == null && this.rowTail == null && this.colTail == null && this.rowSize == 0 && this.colSize == 0;
	}

	public void addFirstRow(E ... values) {
		Array2DNode<E> temp;
		Array2DNode<E>[] store = new Array2DNode[values.length];

		for(int i=0; i<values.length;i++) {
			temp = new Array2DNode(values[i]);	
			store[i]=temp;
		}

		if((values.length)!=colSize && !(isEmpty()))
			throw new IllegalArgumentException("The number of values passed doesn't match the current number of columns.");

		if (this.isEmpty()) {
			colSize=values.length;
			this.head = store[0];
			this.rowTail= store[values.length-1];

			for(int i=0; i<values.length-1;i++) 
				store[i].nextCol=store[i+1];

			this.colTail=head;
		}
		else {
			store[0].nextRow = this.head;

			this.head = store[0];
			this.colTail= store[values.length-1];

			for(int i=0; i<values.length-1;i++) 
				store[i].nextRow=store[i+1];

			temp=this.head;

			for(int i=0; i<values.length;i++) {
				store[i].nextCol=temp;
				temp=temp.nextRow;
			}
		}
		this.rowSize++;
	}

	public void addFirstCol(E ... values) {
		Array2DNode<E> temp;
		Array2DNode<E>[] store = new Array2DNode[values.length];

		for(int i=0; i<values.length;i++) {
			temp = new Array2DNode(values[i]);	
			store[i]=temp;
		}

		if((values.length)!=rowSize && !(isEmpty())) 
			throw new IllegalArgumentException("The number of values passed doesn't match the current number of rows.");

		if (this.isEmpty()) {
			rowSize=values.length;
			this.head = store[0];
			this.colTail= store[values.length-1];

			for(int i=0; i<values.length-1;i++) 
				store[i].nextCol=store[i+1];

			this.rowTail=head;
		}
		else {
			store[0].nextCol = this.head;

			this.head = store[0];
			this.rowTail= store[values.length-1];

			for(int i=0; i<values.length-1;i++) 
				store[i].nextCol=store[i+1];

			temp=this.head;

			for(int i=0; i<values.length;i++) {
				store[i].nextRow=temp;
				temp=temp.nextCol;
			}
		}
		this.colSize++;
	}

	public void addLastRow(E ... values){
		Array2DNode<E> temp = new Array2DNode(values);

		if (this.isEmpty())
			this.head = this.rowTail = temp;
		else {
			this.rowTail.nextRow = temp;
			this.rowTail = temp;
		}
		this.rowSize++;
	}

	public void addLastCol(E ... values){
		Array2DNode<E> temp = new Array2DNode(values);

		if (this.isEmpty()) 
			this.head = this.colTail = temp;
		else {
			this.colTail.nextCol = temp;
			this.colTail = temp;
		}
		this.colSize++;
	}
}