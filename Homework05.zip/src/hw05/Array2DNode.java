package hw05;

public class Array2DNode<E> {

	protected E item;

	public E getItem() {return item;}

	public void setItem(E item) {this.item = item;}

	protected Array2DNode<E> nextCol, nextRow;

	Array2DNode(E value){item=value;}

	@Override
	public String toString() {return this.item.toString();}
}